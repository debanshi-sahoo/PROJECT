package com.mentorlee.Mentorlee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MentorleeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MentorleeApplication.class, args);
	}

}
