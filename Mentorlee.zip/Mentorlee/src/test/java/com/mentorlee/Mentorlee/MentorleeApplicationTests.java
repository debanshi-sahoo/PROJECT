package com.mentorlee.Mentorlee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentorleeApplicationTests {

	@Test
	void contextLoads() {
	}

}
